
$(document).ready(function() {
        $('.all_los').mouseenter(function(){
            $(this).css({
                "left": "2%",
          })
      })
      
      $('.all_los').mouseleave(function(){
          $(this).css({
            "left": "0",
          })
      })
      
});